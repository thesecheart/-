// 独立的整数位运算实现，用于与主程序的字符串实现交叉核验。
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const SDES=require('./sdes.js');
function permutation(value,width,table){return table.reduce((result,position)=>(result<<1)|((value>>(width-position))&1),0);}
function rotateFive(value,amount){return ((value<<amount)|(value>>(5-amount)))&31;}
function referenceKeys(key){
 const permuted=permutation(key,10,[3,5,2,7,4,10,1,9,8,6]);
 let left=rotateFive(permuted>>5,1),right=rotateFive(permuted&31,1);
 const first=permutation((left<<5)|right,10,[6,3,7,4,8,5,10,9]);
 left=rotateFive(left,2);right=rotateFive(right,2);
 return [first,permutation((left<<5)|right,10,[6,3,7,4,8,5,10,9])];
}
function referenceRound(state,key){
 const right=state&15,left=state>>4;
 const mixed=permutation(right,4,[4,1,2,3,2,3,4,1])^key;
 const boxes=[[[1,0,3,2],[3,2,1,0],[0,2,1,3],[3,1,0,2]],[[0,1,2,3],[2,3,1,0],[3,0,1,2],[2,1,0,3]]];
 const output=[mixed>>4,mixed&15].map((value,index)=>boxes[index][((value>>2)&2)|(value&1)][(value>>1)&3]);
 const functionValue=permutation((output[0]<<2)|output[1],4,[2,4,3,1]);
 return ((left^functionValue)<<4)|right;
}
function referenceCipher(block,key,decrypt=false){
 const keys=referenceKeys(key);if(decrypt)keys.reverse();
 let state=referenceRound(permutation(block,8,[2,6,3,1,4,8,5,7]),keys[0]);
 state=((state&15)<<4)|(state>>4);
 return permutation(referenceRound(state,keys[1]),8,[4,1,3,5,7,2,8,6]);
}
const binary=(value,width)=>value.toString(2).padStart(width,'0');
const report={generatedAt:new Date().toISOString(),standard:'作业详细文档指定S盒；LS-1后继续LS-2',basic:{checkedPairs:0,passed:true},internalCrossCheck:{independentImplementation:'整数位运算参考实现',checkedPairs:0,passed:true},externalGroupTest:{status:'待与另一组实际测试，未代填'},ascii:{all128Characters:true},bruteForce:[],collisions:{checkedPlaintexts:256,allHaveCollisions:true}};
for(let key=0;key<1024;key++){
 const keyText=binary(key,10);
 assert.deepEqual(SDES.keyExpansion(keyText),referenceKeys(key).map(value=>binary(value,8)));
 for(let block=0;block<256;block++){
  const plain=binary(block,8),cipher=SDES.encrypt(plain,keyText);
  assert.equal(SDES.decrypt(cipher,keyText),plain);report.basic.checkedPairs++;
  assert.equal(cipher,binary(referenceCipher(block,key),8));
  assert.equal(SDES.decrypt(binary(block,8),keyText),binary(referenceCipher(block,key,true),8));report.internalCrossCheck.checkedPairs++;
 }
}
const ascii=Array.from({length:128},(_,n)=>String.fromCharCode(n)).join('');
assert.equal(SDES.decryptAscii(SDES.encryptAscii(ascii,'1010000010'),'1010000010'),ascii);
report.ascii.example={plaintext:'Hello, S-DES!',ciphertextHex:SDES.toHex(SDES.encryptAscii('Hello, S-DES!','1010000010'))};
const knownPlaintexts=['11010111','00000000','10101010','00001000'];
for(let count=1;count<=knownPlaintexts.length;count++){
 const pairs=knownPlaintexts.slice(0,count).map(plain=>[plain,SDES.encrypt(plain,'1010000010')]);
 const started=new Date().toISOString(),time=performance.now(),candidates=SDES.bruteForce(pairs),elapsedMs=performance.now()-time;
 assert(candidates.includes('1010000010'));report.bruteForce.push({started,finished:new Date().toISOString(),elapsedMs,pairs,candidates});
}
const statistics=[];
for(let plain=0;plain<256;plain++){
 const result=SDES.collisionTest(binary(plain,8));assert(result.collisionGroups>0);
 statistics.push([result.plaintext,result.distinctCiphertexts,result.collisionGroups,result.maxKeysPerCiphertext]);
}
report.collisions.example=SDES.collisionTest('11010111');
fs.writeFileSync(path.join(__dirname,'测试结果.json'),JSON.stringify(report,null,2));
fs.writeFileSync(path.join(__dirname,'密钥碰撞统计.csv'),'plaintext,distinct_ciphertexts,collision_groups,max_keys_per_ciphertext\n'+statistics.map(row=>row.join(',')).join('\n')+'\n');
console.log(JSON.stringify(report,null,2));
