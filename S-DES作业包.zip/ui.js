const element=id=>document.getElementById(id);
function displayError(target,error){element(target).textContent='输入错误：'+error.message;}
function runCipher(action){
 try{
  const key=element('key').value,input=element('data').value;
  if(element('mode').value==='bits')element('result').textContent=(action==='encrypt'?'密文：':'明文：')+SDES[action](input.trim(),key);
  else if(action==='encrypt'){
   const encrypted=SDES.encryptAscii(input,key);
   element('result').textContent='密文（十六进制）：'+SDES.toHex(encrypted)+'\n密文字符（控制字符转义显示）：'+JSON.stringify(encrypted);
  }else element('result').textContent='解密明文：'+SDES.decryptAscii(SDES.fromHex(input.trim()),key);
 }catch(error){displayError('result',error);}
}
element('encrypt').onclick=()=>runCipher('encrypt');
element('decrypt').onclick=()=>runCipher('decrypt');
element('keys').onclick=()=>{try{const keys=SDES.keyExpansion(element('key').value);element('result').textContent=`K1：${keys[0]}\nK2：${keys[1]}`;}catch(error){displayError('result',error);}};
element('mode').onchange=()=>{element('data').value=element('mode').value==='ascii'?'Hello, S-DES!':'11010111';};
function timedCrack(){
 const pairs=element('pairs').value.trim().split(/\r?\n/).filter(line=>line.trim()).map(line=>line.trim().split(':'));
 const started=new Date().toISOString(),start=performance.now();
 const candidates=SDES.bruteForce(pairs),elapsed=performance.now()-start;
 const finished=new Date().toISOString();
 const result={started,finished,elapsedMs:elapsed,pairs,candidates};
 element('crackResult').textContent=`开始时间：${started}\n结束时间：${finished}\n破解耗时：${elapsed.toFixed(3)} ms\n候选密钥数：${candidates.length}\n${candidates.join('\n')}`;
 return result;
}
element('crack').onclick=()=>{try{timedCrack();}catch(error){displayError('crackResult',error);}};
element('collision').onclick=()=>{
 try{const r=SDES.collisionTest(element('collisionPlain').value);element('collisionResult').textContent=`明文：${r.plaintext}\n不同密文数：${r.distinctCiphertexts}\n存在多个密钥的密文组数：${r.collisionGroups}\n同一密文最多对应密钥数：${r.maxKeysPerCiphertext}\n示例密文：${r.example.ciphertext}\n产生该密文的不同密钥：\n${r.example.keys.join('\n')}`;}
 catch(error){displayError('collisionResult',error);}
};
const delay=ms=>new Promise(resolve=>setTimeout(resolve,ms));
let videoUrl;
element('record').onclick=async()=>{
 const button=element('record'),canvas=element('recordCanvas');let recorder,stream;
 try{
  if(!window.MediaRecorder||!canvas.captureStream)throw Error('当前浏览器不支持录制，请使用新版Edge或Chrome');
  button.disabled=true;
  const context=canvas.getContext('2d');
  function draw(lines){context.fillStyle='#f5f8fc';context.fillRect(0,0,960,540);context.fillStyle='#1c2b40';context.font='bold 34px sans-serif';context.fillText('S-DES brute force demonstration',40,65);context.font='24px monospace';lines.forEach((line,index)=>context.fillText(line,40,125+index*43));}
  draw(['Key space: 1024','Ready to search all keys...']);
  stream=canvas.captureStream(15);
  const mimeType=['video/webm;codecs=vp9','video/webm;codecs=vp8','video/webm'].find(type=>MediaRecorder.isTypeSupported(type));
  if(!mimeType)throw Error('浏览器无法生成WebM视频');
  recorder=new MediaRecorder(stream,{mimeType});const chunks=[];
  const stopped=new Promise(resolve=>{recorder.onstop=resolve;});
  recorder.ondataavailable=event=>{if(event.data.size)chunks.push(event.data);};recorder.start();
  await delay(800);
  draw(['Searching all 1024 keys...']);await delay(300);
  const result=timedCrack();
  draw([`Start: ${result.started}`,`End:   ${result.finished}`,`Elapsed: ${result.elapsedMs.toFixed(3)} ms`,`Known pairs: ${result.pairs.length}`,`Candidates: ${result.candidates.length}`,`Keys: ${result.candidates.slice(0,4).join(', ')}`,'Completed: all 1024 keys checked']);
  await delay(2200);recorder.stop();await stopped;
  if(videoUrl)URL.revokeObjectURL(videoUrl);
  videoUrl=URL.createObjectURL(new Blob(chunks,{type:mimeType}));
  const link=document.createElement('a');link.href=videoUrl;link.download='S-DES破解演示.webm';link.textContent='下载本次破解演示视频';element('download').replaceChildren(link);
 }catch(error){if(recorder&&recorder.state!=='inactive')recorder.stop();displayError('crackResult',error);}
 finally{if(stream)stream.getTracks().forEach(track=>track.stop());button.disabled=false;}
};
