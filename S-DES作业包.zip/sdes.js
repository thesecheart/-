// 同一算法模块可用于浏览器GUI和Node.js命令行。
const assert = typeof require === 'function' ? require('node:assert/strict') : null;
const P10=[3,5,2,7,4,10,1,9,8,6], P8=[6,3,7,4,8,5,10,9];
const IP=[2,6,3,1,4,8,5,7], INV=[4,1,3,5,7,2,8,6];
const EP=[4,1,2,3,2,3,4,1], P4=[2,4,3,1];
const S0=[[1,0,3,2],[3,2,1,0],[0,2,1,3],[3,1,0,2]];
const S1=[[0,1,2,3],[2,3,1,0],[3,0,1,2],[2,1,0,3]];
const bits=(n,w)=>n.toString(2).padStart(w,'0');
function validate(s,w){if(typeof s!=='string'||s.length!==w||/[^01]/.test(s))throw Error(`请输入${w}位二进制字符串`);return s;}
const perm=(s,t)=>t.map(i=>s[i-1]).join('');
const xor=(a,b)=>[...a].map((x,i)=>String(Number(x)^Number(b[i]))).join('');
function shift(s,n){return [s.slice(0,5),s.slice(5)].map(h=>h.slice(n)+h.slice(0,n)).join('');}
function keyExpansion(key){const s=shift(perm(validate(key,10),P10),1);return [perm(s,P8),perm(shift(s,2),P8)];}
function sbox(s,t){return bits(t[parseInt(s[0]+s[3],2)][parseInt(s.slice(1,3),2)],2);}
function F(r,k){const s=xor(perm(r,EP),k);return perm(sbox(s.slice(0,4),S0)+sbox(s.slice(4),S1),P4);}
function fk(s,k){return xor(s.slice(0,4),F(s.slice(4),k))+s.slice(4);}
function transform(block,keys){let s=fk(perm(validate(block,8),IP),keys[0]);s=s.slice(4)+s.slice(0,4);return perm(fk(s,keys[1]),INV);}
const encrypt=(p,k)=>transform(p,keyExpansion(k));
const decrypt=(c,k)=>transform(c,keyExpansion(k).reverse());
function bruteForce(pairs){
 if(!pairs.length)throw Error('至少提供一组明文:密文');
 pairs.forEach(pair=>{if(pair.length!==2)throw Error('格式为明文:密文');pair.forEach(s=>validate(s,8));});
 return Array.from({length:1024},(_,k)=>bits(k,10)).filter(k=>pairs.every(([p,c])=>encrypt(p,k)===c));
}
function encryptAscii(text,key){
 validate(key,10);
 if([...text].some(character=>character.charCodeAt(0)>127))throw Error('明文仅支持ASCII字符（编码0至127）');
 return [...text].map(character=>String.fromCharCode(parseInt(encrypt(bits(character.charCodeAt(0),8),key),2))).join('');
}
function decryptAscii(ciphertext,key){
 validate(key,10);
 if([...ciphertext].some(character=>character.charCodeAt(0)>255))throw Error('密文字符编码须在0至255之间');
 return [...ciphertext].map(character=>String.fromCharCode(parseInt(decrypt(bits(character.charCodeAt(0),8),key),2))).join('');
}
const toHex=text=>[...text].map(character=>character.charCodeAt(0).toString(16).padStart(2,'0')).join('');
function fromHex(hex){
 if(hex.length%2||/[^0-9a-f]/i.test(hex))throw Error('十六进制密文必须由成对的0至9、a至f字符组成');
 return (hex.match(/../g)||[]).map(byte=>String.fromCharCode(parseInt(byte,16))).join('');
}
function collisionTest(plaintext){
 validate(plaintext,8);
 const groups=new Map();
 for(let keyNumber=0;keyNumber<1024;keyNumber++){
  const key=bits(keyNumber,10),ciphertext=encrypt(plaintext,key);
  if(!groups.has(ciphertext))groups.set(ciphertext,[]);
  groups.get(ciphertext).push(key);
 }
 const repeated=[...groups].filter(([,keys])=>keys.length>1);
 return {plaintext,distinctCiphertexts:groups.size,collisionGroups:repeated.length,
  maxKeysPerCiphertext:Math.max(...[...groups.values()].map(keys=>keys.length)),
  example:{ciphertext:repeated[0][0],keys:repeated[0][1]}};
}
function closureTest(){
 const tables=Array.from({length:1024},(_,k)=>{const keys=keyExpansion(bits(k,10));return Array.from({length:256},(_,p)=>parseInt(transform(bits(p,8),keys),2));});
 const unique=new Set(tables.map(t=>t.join(',')));
 for(let a=0;a<1024;a++)for(let b=0;b<1024;b++){
  const composed=tables[a].map(y=>tables[b][y]);
  if(!unique.has(composed.join(','))){
   // 对每个单密钥，保存一个使其与双重加密不同的明文，作为可复核证据。
   const witnesses=tables.map((t,k)=>({key:bits(k,10),plaintext:bits(t.findIndex((v,p)=>v!==composed[p]),8)}));
   return {closed:false,keyA:bits(a,10),keyB:bits(b,10),distinctMappings:unique.size,witnesses};
  }
 }
 return {closed:true,distinctMappings:unique.size};
}
function test(){
 assert.deepEqual(keyExpansion('1010000010'),['10100100','01000011']);
 assert.equal(encrypt('11010111','1010000010'),'10001100');
 assert.equal(decrypt('10001100','1010000010'),'11010111');
 for(let k=0;k<1024;k++){
  const keys=keyExpansion(bits(k,10)), seen=new Set();
  for(let p=0;p<256;p++){const plain=bits(p,8),c=transform(plain,keys);assert.equal(transform(c,[keys[1],keys[0]]),plain);seen.add(c);}
  assert.equal(seen.size,256);
 }
 assert(bruteForce([['11010111','10001100']]).includes('1010000010'));
 for(const bad of ['', '101', 'abcdefghij','0000000020'])assert.throws(()=>keyExpansion(bad));
 assert.throws(()=>encrypt('0000000','1010000010'));
 for(const text of ['', 'Hello, S-DES!', '\u0000\u007f', Array.from({length:128},(_,n)=>String.fromCharCode(n)).join('')])assert.equal(decryptAscii(fromHex(toHex(encryptAscii(text,'1010000010'))),'1010000010'),text);
 assert.throws(()=>encryptAscii('中文','1010000010'));
 assert.throws(()=>fromHex('abc'));
 for(let p=0;p<256;p++){
  const result=collisionTest(bits(p,8));assert(result.collisionGroups>0);
  result.example.keys.forEach(key=>assert.equal(encrypt(result.plaintext,key),result.example.ciphertext));
 }
 const result=closureTest();assert.equal(result.closed,false);
 result.witnesses.forEach(({key,plaintext:p})=>assert.notEqual(encrypt(encrypt(p,result.keyA),result.keyB),encrypt(p,key)));
 console.log('通过：已知向量、262144组加解密、ASCII全部128字符、256个明文的密钥碰撞、破解、输入检查、非封闭性完整反例');
 console.log('非封闭反例：先用',result.keyA,'再用',result.keyB,'；不同加密映射数量：',result.distinctMappings);
}
const SDES={keyExpansion,encrypt,decrypt,bruteForce,closureTest,encryptAscii,decryptAscii,toHex,fromHex,collisionTest};
if(typeof module!=='undefined')module.exports=SDES;
if(typeof window!=='undefined')window.SDES=SDES;
if(typeof require==='function'&&require.main===module){
 try{
  const [action,...args]=process.argv.slice(2);
  if(action==='test')test();
  else if(action==='keys')console.log(keyExpansion(args[0]));
  else if(action==='encrypt')console.log(encrypt(args[0],args[1]));
  else if(action==='decrypt')console.log(decrypt(args[0],args[1]));
  else if(action==='crack')console.log(bruteForce(args.map(p=>p.split(':'))));
  else if(action==='collisions')console.log(JSON.stringify(collisionTest(args[0]),null,2));
  else if(action==='closure'){const r=closureTest();console.log(JSON.stringify({...r,witnesses:undefined},null,2));}
  else throw Error('用法：node sdes.js test | keys 密钥 | encrypt 明文 密钥 | decrypt 密文 密钥 | crack 明文:密文 [...] | closure');
 }catch(e){console.error(e.message);process.exitCode=1;}
}
